package com.daentech.core;

public class ray_hit {

	public double t;
	public boolean hit;
	
}

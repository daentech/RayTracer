package com.daentech.core;

import com.daentech.core.Lights.Directional;
import com.daentech.core.Lights.Point;
import com.daentech.core.Materials.Diffuse;
import com.daentech.core.Materials.PerfectReflective;
import com.daentech.core.Materials.Phong;
import com.daentech.core.Objects.Circle;
import com.daentech.core.Objects.Plane;
import com.daentech.core.Objects.Sphere;
import com.daentech.core.Objects.Triangle;
import com.daentech.core.Tracers.MultipleObjects;

public class raytracer {
	
	public static void main(String [] args){
		System.out.println("Here");
		
		Scene s = new Scene();
		create_objects(s);
		create_camera(s);
		create_lights(s);

		s.build();
		s.tracer_ptr = new MultipleObjects(s);
		
		s.render_camera();
		
	}
	
	public static void create_objects(Scene s){
		Sphere s1 = new Sphere();
		s1._origin = new Vector3D(10, -5, 0);
		s1._radius = 27;
		Diffuse m = new Diffuse();
		m.set_cd(new Colour(255, 0, 0));
		m.set_ka(0.25);
		m.set_kd(0.65);
		s1.material = m;
		
		PerfectReflective r2 = new PerfectReflective();
		r2.set_cd(new Colour(192, 34, 10));
		r2.set_ka(0.25);
		r2.set_kd(0.5);
		r2.set_ks(0.15);
		r2.set_exp(100);
		r2.set_kr(0.55);
		r2.set_cr(new Colour(255));

		Sphere s2 = new Sphere();
		s2._origin = new Vector3D(0, 20, 30);
		s2._radius = 30;
		s2.material = r2;
		Sphere s4 = new Sphere();
		s4._origin = new Vector3D(0, 20, 90);
		s4._radius = 30;
		s4.material = r2;
		Sphere s5 = new Sphere();
		s5._origin = new Vector3D(-60, 20, 90);
		s5._radius = 30;
		s5.material = r2;
		Sphere s6 = new Sphere();
		s6._origin = new Vector3D(-60, 20, 150);
		s6._radius = 30;
		s6.material = r2;
		Sphere s7 = new Sphere();
		s7._origin = new Vector3D(0, 20, 150);
		s7._radius = 30;
		s7.material = r2;
		Sphere s8 = new Sphere();
		s8._origin = new Vector3D(-60, 20, -30);
		s8._radius = 30;
		s8.material = r2;
		Sphere s9 = new Sphere();
		s9._origin = new Vector3D(0, 20, -30);
		s9._radius = 30;
		s9.material = r2;
		
		Plane p1 = new Plane();
		p1._normal = new Vector3D(0, 1, 0);
		p1._point = new Vector3D(0, -20, 0);
		PerfectReflective r3 = new PerfectReflective();
		r3.set_cd(new Colour(10, 34, 192));
		r3.set_ka(0.25);
		r3.set_kd(0.5);
		r3.set_ks(0.15);
		r3.set_exp(100);
		r3.set_kr(0);
		r3.set_cr(new Colour(10, 34, 192));
		p1.material = r3;
		
		Triangle t1 = new Triangle();
		t1._a = new Vector3D(-100, 0, 0);
		t1._b = new Vector3D(100, 0, 0);
		t1._c = new Vector3D(0, 50, -30);
		t1.set_normal();
		Phong p2 = new Phong();
		p2.set_cd(new Colour(255, 0, 255));
		p2.set_ka(0.25);
		p2.set_kd(0.65);
		p2.set_ks(0.1);
		p2.set_exp(4);
		t1.material = p2;
		
		Sphere s3 = new Sphere();
		s3._origin = new Vector3D(-60, 20, 30);
		s3._radius = 30;
		s3.material = r2;
		
		Circle c1 = new Circle();
		c1._normal = new Vector3D(0, 1, 0.3);
		c1._point = new Vector3D(0, 20, -30);
		c1._radius = 40;
		Phong p3 = new Phong();
		p3.set_cd(new Colour(0, 255, 0));
		p3.set_ka(0.25);
		p3.set_kd(0.65);
		p3.set_ks(0.1);
		p3.set_exp(4);
		c1.material = p3;
		// add objects
		s.add_object(s1);
		//s.add_object(s2);
		s.add_object(p1);
		s.add_object(t1);
		//s.add_object(s3);
		//s.add_object(s4);
		//s.add_object(s5);
		//s.add_object(s6);
		//s.add_object(s7);
		//s.add_object(s8);
		//s.add_object(s9);
		//s.add_object(c1);
	}
	
	public static void create_lights(Scene s){
		Point p = new Point();
		p._origin = new Vector3D(10, 100, 150);
		p._direction = new Vector3D();
		p._colour = new Colour(255, 255, 255);
		p._ls = 1.0;
		s.add_light(p);
		
		Directional d = new Directional();
		d._colour = new Colour(255);
		d._direction = new Vector3D(0, 1, 1);
		d._ls = 0.5;
		s.add_light(d);
	}
	
	public static void create_camera(Scene s){
		s.camera = new Camera();
		s.camera._origin = new Vector3D(-200,130, 400);
		s.camera._lookat = new Vector3D(0, 0, 90);
		s.camera._up = new Vector3D(0, 1, 0);
		s.camera.hres = 400;
		s.camera.vres = 400;
		s.camera._d = 850;
		s.camera.max_depth = 10;
		s.camera.s = 1;
		
		s.camera.compute_uvw();
	}

}


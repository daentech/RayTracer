package com.daentech.core.Materials;

import com.daentech.core.Colour;
import com.daentech.core.ShadeRec;

public class Material {
	
	public Colour _colour;

	public Colour shade(ShadeRec sr) {
		return new Colour();
	}

}
